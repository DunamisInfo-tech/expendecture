from django.shortcuts import render, render_to_response
from django.http import HttpResponse
from .models import SalesReport
from chartit import Datapool, Chart



def home(request):
    first_graph = "my First django graph"
    return HttpResponse(first_graph)


def sales(request):
    price = \
        DataPool(
            series=
            [{'options': {
                'source': SalesReport.objects.all()},
                'terms': [{'month': 'month',
                           'sales': 'sales',
                           'item':'item',
                           'actual_amount':'actual_amount'
                           }]

            }
            ])

    def monthname(month_num):
        names = {1: 'Jan', 2: 'Feb', 3: 'Mar', 4: 'Apr', 5: 'May', 6: 'Jue', 7: 'Jul', 8: 'Aug', 9: 'Sep', 10: 'Oct',
                 11: 'Nov', 12: 'Dec'}
        return names[month_num]

    def profit(sales, actual_price):
        profit = (sales - actual_price)
        return profit

    def loss(sales, actual_price):
        loss = (actual_price - sales)
        return loss



    cht = Chart(
        datasource=sales,
        series_options=
        [{'options': {
            'type': 'line',
            'stacking': False},
            'terms': {
                'month': [
                    'sales',
                     'item',
                     'actual_amount']
            }}],
        chart_options=
        {'title': {
            'text': 'sales Amounts over Months'},
            'xAxis': {
                'title': {'text': 'Sales Total'}},
            'yAxis': {
                'title': {'text': 'Month Number'}}},
        x_sortf_mapf_mts=(None, monthname, profit, loss, False))
    cht2 = Chart(
        datasource=sales,
        series_options=
        [{'options': {
            'type': 'pie',
            'stacking': False},
            'terms': {
                'month': [
                    'sales',
                     'item',
                     'actual_amount']

            }}],
        chart_options=
        {'title': {
            'text': 'sales Amounts Over Months - pie Chart'},
            'xAxis': {
                'title': {'text': 'Sales Total'}},
            'yAxis': {
                'title': {'text': 'Month Number'}}},
        x_sortf_mapf_mts=(None, monthname, profit, loss, False))

    return render(request, 'sales.html',
                  {'chart_list': [cht, cht2]})
