from django.contrib import admin
from .models import SalesReport

admin.site.register(SalesReport)
