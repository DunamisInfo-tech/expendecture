from django.apps import AppConfig


class KouaConfig(AppConfig):
    name = 'koua'
